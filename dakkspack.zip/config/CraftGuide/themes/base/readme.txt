Note: Do not alter any of the files in this directory, they are overwritten when CraftGuide loads.

If you want to customize or completely replace this, create a new theme and change currentTheme.txt so that the new theme loads instead of this one.